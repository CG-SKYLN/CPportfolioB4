class Box{
  constructor(l, w, h) {
    if(l == "" && w == "" && h == "") {
      this.length = 0;
      this.width = 0;
      this.height = 0;
    }
    else{
      this.length = l;
      this.width = w;
      this.height = h;
    }
  }
  volume() {
   this.vol = (this.length * this.width * this.height).toFixed(2);
   return this.vol
  }
  surfaceArea() {
    this.surAr = (2 * ((this.width * this.length) + (this.height * this.length) + (this.height * this.width))).toFixed(2);
    return this.surAr
  }
}
module.exports.Box = Box;