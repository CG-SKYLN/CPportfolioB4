class ObjectMeasurer{
  constructor(mode){
   this.hasChosen = false;
    while(this.hasChosen == false){
      switch(mode) {
        case "1":
          this.hasChosen = true;
          this.mode = mode;
        break;
        case "2":
          this.hasChosen = true;
          this.mode = mode;
        break;
        case "3":
          this.hasChosen = true;
          this.mode = mode;
        break;
        default:
          console.log("Please enter a number that corresponds with the object being measured.")
          this.mode = mode;
          this.hasChosen = true;
      }
    }
  }
  makebox(l, w, h){
            var bx = require("./box")
            var box1 = new bx.Box(l, w, h);
          console.log("This box's total volume is", box1.volume(), "ft³, and it's total surface area is", box1.surfaceArea(), "ft².")
  }

  makepyramid(l, w, h){
            var pyr = require("./pyramid")
            var pyramid1 = new pyr.Pyramid(l, w, h);
          console.log("This pyramid's total volume is", pyramid1.volume(), "ft³, and it's total surface area is", pyramid1.surfaceArea(), "ft².")
  }

  makesphere(r){
            var sph = require("./sphere")
            var sphere1 = new sph.Sphere(r);
          console.log("This sphere's total volume is around", sphere1.volume(), "ft³, and it's total surface area is about", sphere1.surfaceArea(), "ft².")
  }
}
module.exports.ObjectMeasurer = ObjectMeasurer;