var tester = require("./shapetester");
var shapes = new tester.ObjectMeasurer(prompt("Welcome to the Object Measurer! We will take some of your object's dimensions in feet, and then find the volume and surface area. Would you like to find the volume and surface area of: 1 - a box, 2 - a pyramid, or 3 - a sphere?"))

switch(shapes.mode){
  case "1":
  shapes.makebox(prompt("Please enter a length for your box. "), prompt("Please enter a width for your box. "), prompt("Please enter a height for your box. "))
  break;
  case "2":
  shapes.makepyramid(prompt("Please enter a length for your pyramid. "), prompt("Please enter a width for your pyramid. "), prompt("Please enter a height for your pyramid. "))
  break;
  case "3":
  shapes.makesphere(prompt("Please enter the radius of your sphere. (The distance from the center to the surface.) "))
}