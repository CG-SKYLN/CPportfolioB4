class Pyramid{
  constructor(l, w, h) {
    if(l == "" && w == "" && h == "") {
      this.length = 0;
      this.width = 0;
      this.height = 0;
    } 
    else {
      this.length = l;
      this.width = w;
      this.height = h;
    }
  }
  volume() {
   this.vol = ((this.length * this.width * this.height)/3).toFixed(2);
   return this.vol
  }
  surfaceArea() {
    this.surAr = (this.length * this.width + this.length * Math.sqrt(Math.pow((this.width / 2), 2) + Math.pow(this.height, 2)) + this.width * Math.sqrt(Math.pow((this.length / 2), 2) + Math.pow(this.height, 2))).toFixed(2);
    return this.surAr
  }
}
module.exports.Pyramid = Pyramid;