class Sphere{
  constructor(r) {
    if(r == "") {
      this.radius = 0;
    }
    else {
      this.radius = r;
    }
    this.diameter = r * 2;
    this.circumf = (this.diameter * Math.PI).toFixed(2);
  }
  volume() {
   this.vol = ((4/3) * Math.PI * Math.pow(this.radius, 3)).toFixed(2);
   return this.vol
  }
  surfaceArea() {
    this.surAr = (4 * Math.PI * Math.pow(this.radius, 2)).toFixed(2);
    return this.surAr
  }
}
module.exports.Sphere = Sphere;